create function product_tsvector_trigger() returns trigger
    language plpgsql
as
$$
begin
        new.document_index :=
            setweight(to_tsvector('english', coalesce(new.name, '')), 'A')
            || setweight(to_tsvector('english', coalesce(new.manufacturer, '')), 'B')
            || setweight(to_tsvector('english', coalesce(new.description, '')), 'C')
            || setweight(to_tsvector('english', coalesce(new.type, '')), 'D');
        return new;
end
$$;

alter function product_tsvector_trigger() owner to benbarron;

